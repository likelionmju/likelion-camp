#!c:\ny life\대외활동\멋쟁이사자처럼\프로젝트\likelion-camp\myvenv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
