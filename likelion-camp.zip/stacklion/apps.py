from django.apps import AppConfig


class StacklionConfig(AppConfig):
    name = 'stacklion'
