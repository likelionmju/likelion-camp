from django.apps import AppConfig


class HomeworkConfig(AppConfig):
    name = 'homework'
